Forest Home Serif — font family starter build

This font family is based on EB Garamond 12, an open-source typeface distributed
under the SIL Open Font License 1.1. The font files have been renamed for this
custom style-matched build. The reference image supplied in this conversation
shows only a partial alphabet, so unseen glyphs are drawn from the EB Garamond
base rather than reconstructed from the image.

Original project: EB Garamond
License: SIL Open Font License 1.1
License text: https://openfontlicense.org/
